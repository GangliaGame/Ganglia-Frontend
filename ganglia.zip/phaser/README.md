## How to run

1. In terminal, go to this directory.

2. Run `python -m SimpleHTTPServer 8000`

3. Then, go to http://localhost:8000 in Chrome.
